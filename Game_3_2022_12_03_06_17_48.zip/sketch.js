let currentActivity = 0;
let playButton, exitButton, lbButton, settingButton;
let bColor = "#DCDCDC";
let fontBold;
let score = 0;
let scoreBox;

function preload() {
  // fontBold = loadFont('assets/PressStart.ttf');
}

let space = 5;
let brAckt = [];
let diff = 5;
let ts = 80;
let wide;
let v = {};
let var1 = 0;
let clicked = false;
let gameFinal = false;

function setup() {
  createCanvas(400, 530);

  //fill('black');

  playButton = createButton("PLAY");
  playButton.position(275, 500);
  playButton.size(100, 30);
  playButton.style("font-family", "fantasy");
  // playButton.mousePressed(playButtonPressed);
  playButton.mousePressed(mousePressed);
  exitButton = createButton("RESET");
  exitButton.position(275, 470);
  exitButton.size(100, 30);
  exitButton.mousePressed(resetGame);

  background(0);
  fill("white");
  rect(10, 450, 220, 500);
  fill("black");

  scoreBox = text("SCORE: " + score, 20, 500);

  fill("green");
  textSize(ts);
  textAlign(CENTER, CENTER);
  wide = (1 * width) / 5;
  let c1 = width / 2;
  let c2 = width / space;
  for (let r = 0; r < space; r++) {
    for (let c = 0; c < space; c++) {
      brAckt.push(createVector(c1 / space + r * c2, c1 / space + c * c2));
    }
  }

  let temparr = [];
  arrayCopy(brAckt, temparr);
  for (let i = 0; i < diff; i++) {
    rndpos = int(random(0, temparr.length));
    v[i] = temparr[rndpos];
    temparr.splice(rndpos, 1);
    text(i, v[i].x, v[i].y);
  }
}

//function mousePressed(){
//function playButtonPressed(){
function mousePressed() {
  if (var1 == 0) {
    fill("red");
    for (let i = 0; i < brAckt.length; i++) {
      ellipse(brAckt[i].x - wide / 400, brAckt[i].y - wide / 400, wide);
    }

    var1 = 1;
  } else {
    if (!gameFinal) {
      // function mousePressed() {
      for (let i1 = 0; i1 < brAckt.length; i1++) {
        if (
          abs(brAckt[i1].x - mouseX) <= wide / 2 &&
          abs(brAckt[i1].y - mouseY) <= wide / 2
        ) {
          fill("green");
          ellipse(brAckt[i1].x - wide / 400, brAckt[i1].y - wide / 400, wide);
          clicked = false;
          for (let i2 = 0; i2 < diff; i2++) {
            if (brAckt[i1] == v[i2]) {
              fill("green");

              text(i2, v[i2].x, v[i2].y);

              clicked = true;

              break;
            }
          }

          if (clicked) {
          } else {
            gameFinal = true;
            background(0);
            for (let i1 = 0; i1 < diff; i1++) {
              fill("black");
              //fill('red');
              text(i1, v[i1].x, v[i1].y);
            }
            fill("red");
            //console.log("GAME OVER");
            textSize(30);
            text("GAME OVER", 200, 250);
          }
        } else {
        }
      }
    }
  }
}

function resetGame() {
  space = 5;
  brAckt = [];
  diff = 5;
  ts = 80;
  wide;
  v = {};
  var1 = 0;
  clicked = false;
  gameFinal = false;
  setup();
}
