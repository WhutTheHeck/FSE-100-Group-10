let currentActivity = 0;
let playButton, exitButton, lbButton, settingButton;
let bColor = '#DCDCDC';

function preload() {
  
}

function setup() {
  createCanvas(750, 500);
  background(bColor);
  
  gameTitle = createElement('h2', 'Stroke Recovery Games');
  gameTitle.position(250, 50);
  textAlign(CENTER);
  textSize(50);
  
  playButton = createButton("PLAY");
  playButton.position(275, 200);
  playButton.size(200, 30);
  playButton.style('font-family', 'fantasy');
  playButton.mousePressed(gameScreenSetup);

  exitButton = createButton("EXIT");
  exitButton.position(275, 250);
  exitButton.size(200, 30);
  exitButton.mousePressed(exitGame);

  settingButton = createButton("SETTINGS");
  settingButton.position(275, 300);
  settingButton.size(200, 30);
  settingButton.mousePressed(settingScreenSetup);
}

function draw() {}

function exitGame()
{
  remove();
}
