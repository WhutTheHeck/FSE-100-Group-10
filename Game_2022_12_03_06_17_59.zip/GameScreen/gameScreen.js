function gameScreenSetup()
{
  playButton.hide();
  exitButton.hide();

  settingButton.hide();
  
  createCanvas(750, 500);
  background(bColor);
  game1Button = createButton("GAME 1 + 2");
  game1Button.position(275, 200);
  game1Button.size(200, 30);
  game1Button.mousePressed(game1Setup);

  game3Button = createButton("GAME 3");
  game3Button.position(275, 280);
  game3Button.size(200, 30);
  game3Button.mousePressed(game3Setup);
  
  backButton = createButton("BACK");
  backButton.position(275, 360);
  backButton.size(200, 30);
  backButton.mousePressed(back);
}


function back()
{
  playButton.show();
  exitButton.show();

  settingButton.show();
  game1Button.hide();

  game3Button.hide();
  backButton.hide();
}

function hideButtons()
{
  playButton.hide();
  exitButton.hide();

  settingButton.hide();
  game1Button.hide();

  game3Button.hide();
  backButton.hide();
}

function game1Setup()
{
  window.open("https://editor.p5js.org/jchen548/sketches/bFb1eVysv");
}

function game3Setup()
{
  window.open("https://editor.p5js.org/jchen548/sketches/1e7bRCSMi");
}

