function settingScreenSetup() 
{
  playButton.hide();
  exitButton.hide();

  settingButton.hide();
  
  createCanvas(750, 500);
  background(bColor);
  
  colorPicker = createColorPicker('#DCDCDC');
  colorPicker.position(275,200);
  colorPicker.size(85,30);
  
  applyButton = createButton("APPLY");
  applyButton.position(370, 200);
  applyButton.size(105, 30);
  applyButton.mousePressed(implement); 
  
  backButton = createButton("BACK");
  backButton.position(275, 360);
  backButton.size(200, 30);
  backButton.mousePressed(settingBack);
}

function implement()
{
  bColor = colorPicker.color();
  background(bColor);
}

function settingBack()
{
  playButton.show();
  exitButton.show();

  settingButton.show();
  applyButton.hide();
  colorPicker.hide();
  backButton.hide();
}