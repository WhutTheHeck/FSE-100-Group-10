let currentActivity = 0;
let timer = 10;
var score = 0;
var x = 320;
var y = 320;
var bgcolor;
let greeting, input;
let scoreText = "Score: " + score;
let timerText = "Time: " + timer;
let scoreWin, scoreLost, gameTitle;
let showText = false;
let showText1 = false;

let space = 5;
let brAckt = [];
let diff = 5;
let ts = 80;
let wide;
let v = {};
let var1 = 0;
let clicked = false;
let gameFinal = false;

let game1Button,
  game2Button,
  game3Button,
  button1,
  homeButton,
  submitButton,
  game1Introduction,
  game2Introduction;
var score3 = 0;
let apple, tiger, monkey, banana, strawberry, lemon, img6, img7, img8, c;
let currentImage;
//variable to store button
let switcher;
let victorySound, failureSound;
function preload() {
  // preload() runs once
  apple = loadImage(
    "https://images.everydayhealth.com/images/apples-101-about-1440x810.jpg"
  );
  console.log("image loaded");
  tiger = loadImage(
    "https://upload.wikimedia.org/wikipedia/commons/4/41/Siberischer_tiger_de_edit02.jpg"
  );
  monkey = loadImage(
    "https://t4.ftcdn.net/jpg/00/28/08/39/360_F_28083990_8eMo3jGNyPoc4AMtWgvIwOCpoO60npAl.jpg"
  );
  lemon = loadImage(
    "https://thumbs.dreamstime.com/b/lemon-fruit-icon-isolated-white-background-flat-style-vector-illustration-76688577.jpg"
  );
  banana = loadImage(
    "https://thumbs.dreamstime.com/b/banana-bunch-18029532.jpg"
  );
  strawberry = loadImage(
    "https://thumbs.dreamstime.com/b/red-strawberry-3227805.jpg"
  );
  currentImage = apple;
  victorySound = loadSound("sound/success-fanfare-trumpets-6185-1.mp3");
  failureSound = loadSound("sound/negative_beeps-6008.mp3");
}

function switchToMM() {
  background(220);
  currentActivity = 0;

  // Hide the home page button, show the activity buttons
  homeButton.hide();
  game1Button.show();
  game2Button.show();
  game3Button.show();
  submitButton.hide();
  greeting.hide();
  input.hide();
  button1.hide();
  switcher.hide();
  scoreWin.hide();
  scoreLost.hide();
  game1Title.hide();
  gameTitle.hide();
  game1Introduction.show();
  game2Introduction.show();
}

function setup() {
  print("called setup()");
  createCanvas(400, 400);
  background(220);
  background(255, 204, 0);
  //image(img, 50, 60, 200, 200);

  game1Button = createButton("Game 1");
  game1Button.position(0, 0);

  game1Button.show();

  game2Button = createButton("Game 2");
  game2Button.position(0, 25);
  game2Button.mousePressed(game2Setup);
  game2Button.show();

  game3Button = createButton("Game3");
  game3Button.position(0, 50);
  game3Button.mousePressed(game3Setup);
  game3Button.show();

  homeButton = createButton("Home");
  homeButton.position(0, 100);
  homeButton.mousePressed(() => {
    switchToMM();
    //setup();
  });
  homeButton.hide();

  game1Introduction = createButton("game1Introduction");
  game1Introduction.position(50, 200);
  game1Introduction.mousePressed(() => {
    introduction();
  });
  //game1Introduction.hide();
  game1Button.mousePressed(() => {
    game1Setup();
    game1Introduction.hide();
    game2Introduction.hide();
    gameTitle.hide();
  });

  game2Introduction = createButton("game2Introduction");
  game2Introduction.position(220, 200);
  game2Introduction.mousePressed(introduction2);
  //game2Introduction.hide();

  gameTitle = createElement("h2", "Stroke Recovery Games");
  gameTitle.position(105, 5);
  textAlign(CENTER);
  textSize(50);

  //game 1
  input = createInput();
  input.position(20, 300);
  submitButton = createButton("submit");
  submitButton.position(input.x + input.width, 300);
  greeting = createElement("h2", "Please type your word here");
  greeting.position(20, 315);
  textAlign(CENTER);
  textSize(50);
  submitButton.mousePressed(greet);
  submitButton.hide();
  greeting.hide();
  input.hide();

  scoreWin = createElement("h2", "You win!");
  scoreWin.position(125, 150);
  textAlign(CENTER);
  textSize(50);
  scoreWin.hide();

  scoreLost = createElement("h2", "You lost!");
  scoreLost.position(125, 150);
  textAlign(CENTER);
  textSize(50);
  scoreLost.hide();

  game1Title = createElement("h2", "Typing Practice");
  game1Title.position(125, 10);
  textAlign(CENTER);
  textSize(50);
  game1Title.hide();

  switcher = createButton("Change Image");
  switcher.position(250, 300);
  switcher.mousePressed(changeImg);
  switcher.hide();

  //game 2
  button1 = createImg(
    "https://static.vecteezy.com/system/resources/previews/008/848/358/original/fresh-lemon-fruit-free-png.png",
    "fruit-one"
  );
  button1.position(x, y);
  button1.size(50, 50);
  r = random(255);
  g = random(255);
  b = random(255);
  button1.mousePressed(changeColor);
  button1.mousePressed(randomLocation);
  // textSize(20);
  // text(scoreText, 330, 20);
  button1.hide();
  //text.hide();
}

let button;
function game1Setup() {
  clear();
  background(220);
  //background(r, g, b);
  background(255, 204, 0);
  //background(220);
  //image(img, 20, 75, 200, 200);
  currentActivity = 1;
  game1Button.show();
  game2Button.show();
  game3Button.show();
  homeButton.show();

  submitButton.show();
  greeting.show();
  input.show();
  button1.hide();
  switcher.show();
  //draw the current image
  // image(image,x,y,width,height);
  image(currentImage, 20, 75, 200, 200);
  scoreWin.hide();
  scoreLost.hide();
  game1Title.show();
  //gameTitle.hide();
  game1Introduction.hide();
  game2Introduction.hide();
}
function greet() {
  const word = input.value();
  if ((word === "Apple" || word === "apple") && currentImage == apple) {
    greeting.html("Your word " + word + " is correct !");
    input.value("");
    victorySound.play();
  } else if (currentImage == tiger && (word === "tiger" || word === "Tiger")) {
    greeting.html("Your word " + word + " is correct !");
    input.value("");
    victorySound.play();
  } else if (
    currentImage == monkey &&
    (word === "monkey" || word === "Monkey")
  ) {
    greeting.html("Your word " + word + " is correct !");
    input.value("");
    victorySound.play();
  } else if (currentImage == lemon && (word === "lemon" || word === "Lemon")) {
    greeting.html("Your word " + word + " is correct !");
    input.value("");
    victorySound.play();
  } else if (
    currentImage == banana &&
    (word === "banana" || word === "Banana")
  ) {
    greeting.html("Your word " + word + " is correct !");
    input.value("");
    victorySound.play();
  } else if (
    currentImage == strawberry &&
    (word === "strawberry" || word === "Strawberry")
  ) {
    greeting.html("Your word " + word + " is correct !");
    input.value("");
    victorySound.play();
  } else {
    greeting.html("Your word " + word + " is wrong !");
    input.value("");
    failureSound.play();
  }
}

//game2 if time== 30, reset score and show game over.
function game2Setup() {
  console.log("in game2 here");
  background(220);

  // write code here to iterate through button   array, and type .remove on all ones
  textSize(20);
  text(scoreText, 330, 20);
  //timer
  textSize(20);
  text(scoreText, 330, 40);
  currentActivity = 2;
  game1Button.show();
  game2Button.show();
  homeButton.show();
  submitButton.hide();
  greeting.hide();
  input.hide();
  button1.show();
  switcher.hide();
  scoreWin.hide();
  scoreLost.hide();
  game1Title.hide();
  gameTitle.hide();
  game1Introduction.hide();
  game2Introduction.hide();
  timer = 10;
  score = 0;
}

function game3Setup() {
  submitButton.hide();
  greeting.hide();
  input.hide();
  switcher.hide();
  scoreWin.hide();
  scoreLost.hide();
  game1Introduction.hide();
  game2Introduction.hide();
  gameTitle.hide();
  game1Title.hide();
  button1.hide();
  createCanvas(400, 530);
  currentActivity = 5;

  //fill('black');


  start3Button = createButton("START");
  start3Button.position(275, 470);
  start3Button.size(100, 30);
  start3Button.mousePressed(game3MousePressed);

  background(0);
  fill("white");
  rect(10, 450, 220, 500);
  fill("black");

  text("SCORE: " + score3, 20, 500);

  fill("green");
  textSize(ts);
  textAlign(CENTER, CENTER);
  wide = (1 * width) / 5;
  let c1 = width / 2;
  let c2 = width / space;
  for (let r = 0; r < space; r++) {
    for (let c = 0; c < space; c++) {
      brAckt.push(createVector(c1 / space + r * c2, c1 / space + c * c2));
    }
  }

  let temparr = [];
  arrayCopy(brAckt, temparr);
  for (let i = 0; i < diff; i++) {
    rndpos = int(random(0, temparr.length));
    v[i] = temparr[rndpos];
    temparr.splice(rndpos, 1);
    text(i, v[i].x, v[i].y);
  }
}

function game1Draw() {
  // background(220);
  // image(img, 20, 75, 200, 200);
}
function game2Draw() {
  if (currentActivity == 2) {
    background(220);
    //text(scoreText, 330, 20);
    //background(r, g, b);
    background(255, 204, 0);
    text("score = " + score, 335, 20);
    text("time = " + timer, 330, 40);
    if (frameCount % 60 == 0 && timer > 0) {
      // if the frameCount is divisible by 60, then a second has passed. it will stop at 0
      timer--;
    }
    if (timer == 0 && score < 10) {
      button1.hide();
      scoreLost.show();
      //failureSound.play();
    }
  }
}
function game3Draw() {
  // background(220);
  // image(img, 20, 75, 200, 200);
}


function mainMenu() {
  currentActivity = 0;
  background(220);
  //background(r, g, b);
  background(255, 204, 0);
  //setup();

  submitButton.hide();
  greeting.hide();
  input.hide();
  switcher.hide();
  //gameTitle.hide();
}
function draw() {
  switch (currentActivity) {
    case 0:
      mainMenu();
      break;
    case 1:
      game1Setup();
      break;
    case 2:
      game2Draw();
      break;
    case 3:
      introduction();
      break;
    case 4:
      introduction2();
      break;
    case 5:
      game3Draw();
      break;
  }
}

function randomLocation() {
  x = random(windowWidth / 1.8);
  y = random(windowHeight / 1.8);
  button1.position(x, y);
  //bground = [random(10), random(20)];
  score = score + 1;
  //timer = 50;
  if (score >= 10) {
    //score = 0;
    //timer =10;
    scoreWin.show();
    //switchToMM();
    button1.hide();
    //game2Button.hide();
    victorySound.play();
  }
}
function mousePressed() {}

function game3MousePressed() {
  console.log("pressed");
  if (var1 == 0) {
    fill("red");
    for (let i = 0; i < brAckt.length; i++) {
      ellipse(brAckt[i].x - wide / 400, brAckt[i].y - wide / 400, wide);
    }

    var1 = 1;
  } else {
    if (!gameFinal) {
      // function mousePressed() {
      for (let i1 = 0; i1 < brAckt.length; i1++) {
        if (
          abs(brAckt[i1].x - mouseX) <= wide / 2 &&
          abs(brAckt[i1].y - mouseY) <= wide / 2
        ) {
          fill("green");
          ellipse(brAckt[i1].x - wide / 400, brAckt[i1].y - wide / 400, wide);
          clicked = false;
          for (let i2 = 0; i2 < diff; i2++) {
            if (brAckt[i1] == v[i2]) {
              fill("green");

              text(i2, v[i2].x, v[i2].y);

              clicked = true;

              break;
            }
          }

          if (clicked) {
          } else {
            gameFinal = true;
            background(0);
            for (let i1 = 0; i1 < diff; i1++) {
              fill("black");
              //fill('red');
              text(i1, v[i1].x, v[i1].y);
            }
            fill("red");
            //console.log("GAME OVER");
            textSize(30);
            text("GAME OVER", 200, 250);
          }
        } else {
        }
      }
    }
  }
}

//function to change images
//let flag = true;
function changeImg() {
  currentActivity = 1;
  //flag = !flag;
  if (currentImage == apple) {
    currentImage = tiger;

    console.log("img switched");
  } else if (currentImage == tiger) {
    currentImage = monkey;
  } else if (currentImage == monkey) {
    currentImage = lemon;
  } else if (currentImage == lemon) {
    currentImage = banana;
  } else if (currentImage == banana) {
    currentImage = strawberry;
  } else {
    currentImage = apple;
  }

  //draw the current image
  // image(image,x,y,width,height);
  background(220);
  image(currentImage, 20, 75, 200, 200);
  //background(220);
  //image(img, 20, 75, 200, 200);
}

function changeColor() {
  r = random(255);
  g = random(255);
  b = random(255);
}

function introduction() {
  //game1Title.position(125, 10);
  currentActivity = 3;
  background(220);
  background(255, 204, 0);
  homeButton.show();
  game1Button.show();
  game2Button.show();
  submitButton.hide();
  greeting.hide();
  input.hide();
  button1.hide();
  switcher.hide();
  scoreWin.hide();
  scoreLost.hide();
  game1Title.hide();
  gameTitle.hide();
  game1Introduction.hide();
  game2Introduction.hide();
  showText = true;
  textAlign(CENTER);
  textSize(20);
  if (showText) {
    text(
      "Please type your word based\non the picture provided, you\ncan change image by click on\nsubmit button, click game 1 to start,\nyou can either click home button to exist or\nclick game 2 button start\na different game",
      200,
      200
    );
  }
}

function introduction2() {
  //game1Title.position(125, 10);
  currentActivity = 4;
  background(220);
  background(255, 204, 0);
  homeButton.show();
  game1Button.show();
  game2Button.show();
  submitButton.hide();
  greeting.hide();
  input.hide();
  button1.hide();
  switcher.hide();
  scoreWin.hide();
  scoreLost.hide();
  game1Title.hide();
  gameTitle.hide();
  game1Introduction.hide();
  game2Introduction.hide();

  //removeElements();
  showText = false;
  showText1 = true;
  textAlign(CENTER);
  textSize(20);
  if (showText1) {
    text(
      "Hi welcome to game2!\nYou will need to click the lemon\nimage to win the score,\nif you got a 10 in 10 second,\nyou will win the game, unless\nyou loss this game, click game 2 to start,\nif you want play another round\nclick game 2 again",
      200,
      200
    );
  }
}
